/**
 * 
 */
package com.zk.test.gen.sub.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.zk.base.controller.ZKBaseController;
import com.zk.core.commons.data.ZKPage;
import com.zk.core.web.ZKMsgRes;

import com.zk.test.gen.sub.entity.ZKGenTestModuleSubTestTableGen;
import com.zk.test.gen.sub.service.ZKGenTestModuleSubTestTableGenService;       

/**
 * ZKGenTestModuleSubTestTableGenController
 * @author 
 * @version 
 */
@RestController
@RequestMapping(value = "${zk.path.admin}/${zk.path.genTestModule}/${zk.genTestModule.version}/sub/genTestModuleSubTestTableGen")
public class ZKGenTestModuleSubTestTableGenController extends ZKBaseController {

	@Autowired
	private ZKGenTestModuleSubTestTableGenService genTestModuleSubTestTableGenService;
	
	// 编辑
	@RequestMapping(value="genTestModuleSubTestTableGen", method = RequestMethod.POST)
	public ZKMsgRes genTestModuleSubTestTableGenPost(@RequestBody ZKGenTestModuleSubTestTableGen genTestModuleSubTestTableGen){
		this.genTestModuleSubTestTableGenService.save(genTestModuleSubTestTableGen);
        return ZKMsgRes.asOk(genTestModuleSubTestTableGen);
	}
	
	// 查询详情
	@RequestMapping(value="genTestModuleSubTestTableGen", method = RequestMethod.GET)
	public ZKMsgRes genTestModuleSubTestTableGenGet(@RequestParam("pkId") Date pkId){
		ZKGenTestModuleSubTestTableGen genTestModuleSubTestTableGen = this.genTestModuleSubTestTableGenService.get(new ZKGenTestModuleSubTestTableGen(pkId));
        return ZKMsgRes.asOk(genTestModuleSubTestTableGen);
	}
	
	// 分页查询 
	@RequestMapping(value="genTestModuleSubTestTableGensPage", method = RequestMethod.GET)
	public ZKMsgRes genTestModuleSubTestTableGensPageGet(ZKGenTestModuleSubTestTableGen genTestModuleSubTestTableGen, HttpServletRequest hReq, HttpServletResponse hRes){
		ZKPage<ZKGenTestModuleSubTestTableGen> resPage = ZKPage.asPage(hReq);
        resPage = this.genTestModuleSubTestTableGenService.findPage(resPage, genTestModuleSubTestTableGen);
        return ZKMsgRes.asOk(resPage);
	}
	
	// 批量删除
	@RequestMapping(value="genTestModuleSubTestTableGen", method = RequestMethod.DELETE)
	public ZKMsgRes genTestModuleSubTestTableGenDel(@RequestParam("pkId[]") Date[] pkIds){
		int count = 0;
        if (pkIds != null && pkIds.length > 0) {
            for (Date pkId : pkIds) {
                count += this.genTestModuleSubTestTableGenService.del(new ZKGenTestModuleSubTestTableGen(pkId));
            }
        }
        return ZKMsgRes.asOk(count);
	}

}