/*** 菜单 - 生成菜单 sql ***/

-- 指定模块
set @navCode = 'genTestModule';
-- 指定父菜单ID
set @parentId = NULL;
-- 此功能的根菜单
set @firstId = 6315235388172534272;
set @dateStr = '2022-10-09 02:05:36';

-- c_code 填写父菜单的 代码；插入为指定菜单的子菜单
select c_pk_id into @parentId from t_sys_res_menu where c_code = 'xxx';
-- select max(c_pk_id) into @firstId FROM `zk-sys`.t_sys_res_menu;

INSERT INTO `t_sys_res_menu` (`c_pk_id`,`c_create_user_id`,`c_update_user_id`,`c_create_date`,`c_update_date`,`c_del_flag`,`c_version`,`c_remarks`,`c_p_desc`,`c_spare1`,`c_spare2`,`c_spare3`,`c_spare_json`,
`c_name`,
`c_code`,
`c_parent_id`,
`c_nav_code`,
`c_func_module_code`,
`c_func_name`,
`c_path`,
`c_is_index`,`c_exact`, `c_is_frame`,`c_is_show`,`c_icon`,`c_sort`,`c_permission`) 
VALUES 
	(@firstId,
	NULL,NULL, @dateStr, @dateStr, 0,0,NULL,NULL,NULL,NULL,NULL,NULL,
	'{\"zh-CN\": \"测试代码生成\", \"en-US\": \"GenTestModuleSubTestTableGen\"}',
	'GenTestModuleSubTestTableGen',
	@parentId,
	@navCode,
	'genTestModule',
	'genTestModuleSubTestTableGenIndex',
	'genTestModuleSubTestTableGen',
	0,1,0,1,'',600,NULL),
	(6315235391645417984,
	NULL,NULL, @dateStr, @dateStr,0,0,NULL,NULL,NULL,NULL,NULL,NULL,
	'{\"zh-CN\": \"明细\", \"en-US\": \"Detail\"}',
	'GenTestModuleSubTestTableGen_Detail',
	@firstId,
	@navCode,
	'genTestModule',
	'genTestModuleSubTestTableGenDetail',
	'detail/:pkId',
	0,0,0,0,'UnorderedListOutlined',300,NULL),
	(6315235391645417985,
	NULL,NULL, @dateStr, @dateStr, 0,0,NULL,NULL,NULL,NULL,NULL,NULL,
	'{\"zh-CN\": \"编辑\", \"en-US\": \"Edit\"}',
	'GenTestModuleSubTestTableGen_Edit',
	@firstId,
	@navCode,
	'genTestModule',
	'genTestModuleSubTestTableGenEdit',
	'edit/:pkId',
	0,0,0,0,'FormOutlined',200,NULL);
