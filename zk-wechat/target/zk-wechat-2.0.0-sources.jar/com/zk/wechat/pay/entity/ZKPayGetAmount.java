/** 
* Copyright (c) 2004-2020 ZK-Vinson Technologies, Inc.
* address: 
* All rights reserved. 
* 
* This software is the confidential and proprietary information of 
* ZK-Vinson Technologies, Inc. ("Confidential Information"). You shall not 
* disclose such Confidential Information and shall use it only in 
* accordance with the terms of the license agreement you entered into 
* with ZK-Vinson. 
*
* @Title: ZKPayGetAmount.java 
* @author Vinson 
* @Package com.zk.wechat.pay.entity 
* @Description: TODO(simple description this file what to do. ) 
* @date Feb 19, 2021 9:51:37 PM 
* @version V1.0 
*/
package com.zk.wechat.pay.entity;

import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.Range;
import org.springframework.data.annotation.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.zk.base.entity.ZKBaseEntity;
import com.zk.db.annotation.ZKColumn;
import com.zk.db.annotation.ZKTable;
import com.zk.db.commons.ZKSqlConvertDelegating;
import com.zk.db.mybatis.commons.ZKDBSqlHelper;
import com.zk.wechat.pay.enumType.ZKPayCurrency;

/**
 * 微信支付-收款金额表
 * 
 * @ClassName: ZKPayGetAmount
 * @Description: TODO(simple description this class what to do. )
 * @author Vinson
 * @version 1.0
 */
@ZKTable(name = "t_wx_pay_get_amount", alias = "wxPayGetAmount")
public class ZKPayGetAmount extends ZKBaseEntity<String, ZKPayGetAmount> {

    static ZKDBSqlHelper sqlHelper;

    @Transient
    @XmlTransient
    @JsonIgnore
    @Override
    public ZKDBSqlHelper getSqlHelper() {
        return sqlHelper();
    }

    public static ZKDBSqlHelper sqlHelper() {
        if (sqlHelper == null) {
            sqlHelper = new ZKDBSqlHelper(new ZKSqlConvertDelegating(), new ZKPayGetAmount());
        }
        return sqlHelper;
    }

    /**
     * @Fields serialVersionUID : TODO(simple description what to do.)
     */
    private static final long serialVersionUID = 1L;

    public ZKPayGetAmount() {
        super();
    }

    public ZKPayGetAmount(int total, ZKPayCurrency currency) {
        super();
        this.total = total;
        this.currency = currency;
    }

    public static ZKPayGetAmount as(int total, ZKPayCurrency currency) {
        return new ZKPayGetAmount(total, currency);
    }

    public static ZKPayGetAmount as(int total, String currency) {
        return new ZKPayGetAmount(total, ZKPayCurrency.valueOf(currency));
    }

    // 对应支付记录
    @NotNull(message = "{zk.core.data.validation.notNull}")
    @Length(max = 20, message = "{zk.core.data.validation.length.max}")
    @ZKColumn(name = "c_wx_pay_order_pk_id")
    String payOrderPkId;

    // 总金额 total int 是 订单总金额，单位为分。
    @NotNull(message = "{zk.core.data.validation.notNull}")
    @Range(min = 0, max = 999999999, message = "{zk.core.data.validation.rang.int}")
    @ZKColumn(name = "c_wx_total")
    int total;

    // 货币类型 currency string[1,16] 否 CNY：人民币，境内商户号仅支持人民币; 示例值：CNY。
    @NotNull(message = "{zk.core.data.validation.notNull}")
    @ZKColumn(name = "c_wx_currency")
    ZKPayCurrency currency;

    /**
     * @return payOrderPkId sa
     */
    public String getPayOrderPkId() {
        return payOrderPkId;
    }

    /**
     * @param payOrderPkId
     *            the payOrderPkId to set
     */
    public void setPayOrderPkId(String payOrderPkId) {
        this.payOrderPkId = payOrderPkId;
    }

    /**
     * @return total sa
     */
    public int getTotal() {
        return total;
    }

    /**
     * @param total
     *            the total to set
     */
    public void setTotal(int total) {
        this.total = total;
    }

    /**
     * @return currency sa
     */
    public ZKPayCurrency getCurrency() {
        return currency;
    }

    /**
     * @param currency
     *            the currency to set
     */
    public void setCurrency(ZKPayCurrency currency) {
        this.currency = currency;
    }

}
